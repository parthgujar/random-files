import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DataGenMapper extends Mapper<LongWritable, NullWritable, Text, Text> {
	
	Text key = new Text();
	
	Text value = new Text();
	
	
	@Override
	protected void map(LongWritable random, NullWritable ignore, Context context) throws IOException, InterruptedException{
		
			
		
		 key.set(String.valueOf(Math.random()*1000000000));
		  
		 context.write(key, value); 
	}
	
	
	
	
	
	
}
