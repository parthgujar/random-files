import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableUtils;
import org.apache.hadoop.mapreduce.InputSplit;

public class RangeInputSplit extends InputSplit implements Writable {
	
	
	long rowCount;
	
	
	public RangeInputSplit(){
		
	}
	
	
	public RangeInputSplit(long rowCount){
		
		this.rowCount = rowCount;
	}
	

	@Override
	public void readFields(DataInput in) throws IOException {

		rowCount = WritableUtils.readVLong(in);
		
		
	}

	@Override
	public void write(DataOutput out) throws IOException {

		WritableUtils.writeVLong(out, rowCount);
		
		
	}

	@Override
	public long getLength() throws IOException, InterruptedException {
		return 0;
	}

	@Override
	public String[] getLocations() throws IOException, InterruptedException {
		return new String[]{};
	}

}
