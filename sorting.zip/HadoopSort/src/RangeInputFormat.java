import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

public class RangeInputFormat extends InputFormat<LongWritable, NullWritable> {
	
	
	long rowCount;
	

	@Override
	public RecordReader<LongWritable, NullWritable> createRecordReader(InputSplit split,
			TaskAttemptContext arg1) throws IOException, InterruptedException {
		return new RangeRecordReader((RangeInputSplit) split); 
	}

	@Override
	public List<InputSplit> getSplits(JobContext context) throws IOException,
			InterruptedException {
		 
		   int numSplits = context.getConfiguration().getInt( 
		     "mapred.map.tasks", 2); 
		   
		   long totalRows = context.getConfiguration().getLong("sort.num-rows", 0);
		   long rowsPerSplit = totalRows / numSplits; 
		 
		   System.out.println("Generating " + totalRows + " using " 
		     + numSplits + " maps with step of " + rowsPerSplit); 
		 
		   List<InputSplit> splits = new ArrayList<InputSplit>(numSplits); 
		   long currentRow = 0; 
		   for (int split = 0; split < numSplits - 1; ++split) { 
		    splits.add(new RangeInputSplit(rowsPerSplit)); 
		    currentRow += rowsPerSplit; 
		   } 
		   splits.add(new RangeInputSplit(totalRows - currentRow)); 
		   return splits; 
		  
	}
	


}
