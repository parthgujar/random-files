import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

public class RangeRecordReader extends RecordReader<LongWritable, NullWritable> {
	
	 
	   long startRow; 
	   long finishedRows; 
	   long totalRows; 
	   private LongWritable currentKey = new LongWritable(); 
	 
	   public RangeRecordReader(RangeInputSplit split) { 
	    finishedRows = 0; 
	    totalRows = split.rowCount; 
	   } 
	 
	   @Override 
	   public void close() throws IOException { 
	   } 
	 
	   @Override 
	   public float getProgress() throws IOException { 
	    return finishedRows / (float) totalRows; 
	   } 
	 
	   @Override 
	   public LongWritable getCurrentKey() throws IOException, 
	     InterruptedException { 
	    return currentKey; 
	   } 
	 
	   @Override 
	   public NullWritable getCurrentValue() throws IOException, 
	     InterruptedException { 
	    return NullWritable.get(); 
	   } 
	 
	   @Override 
	   public void initialize(InputSplit split, TaskAttemptContext context) 
	     throws IOException, InterruptedException { 
	   } 
	 
	   @Override 
	   public boolean nextKeyValue() throws IOException, 
	     InterruptedException { 
	    if (finishedRows < totalRows) { 
	     currentKey.set(startRow + finishedRows); 
	     finishedRows += 1; 
	     return true; 
	    } else { 
	     return false; 
	    } 
	   } 
	 
	  
}
